const cards = document.querySelectorAll('.card');
let hasFlippedCard = false;
let firstCard, secondCard;
let lockBoard = false;
let currentPlayer = 1;
let player1Score = { acertos: 0 };
let player2Score = { acertos: 0 };

const playerIndicator = document.getElementById('player-indicator');
const player1AcertosDisplay = document.getElementById('player1-acertos');
const player2AcertosDisplay = document.getElementById('player2-acertos');
const restartButton = document.getElementById('restart-button');

restartButton.addEventListener('click', restartGame);

function restartGame() {
    lockBoard = false;
    currentPlayer = 1;
    player1Score = { acertos: 0 };
    player2Score = { acertos: 0 };

    updateScore();
    playerIndicator.textContent = `Vez do Jogador ${currentPlayer}`;

    cards.forEach((card) => {
        card.classList.remove('flip');
        card.addEventListener('click', flipCard);
    });

    shuffleCards();
}

function shuffleCards() {
    cards.forEach((card) => {
        let randomPosition = Math.floor(Math.random() * 12);
        card.style.order = randomPosition;
    });
}

function switchPlayer() {
    currentPlayer = (currentPlayer === 1) ? 2 : 1;
    console.log(`Vez do jogador ${currentPlayer}`);
    updatePlayerIndicator();
}

function updatePlayerIndicator() {
    playerIndicator.textContent = `Vez do Jogador ${currentPlayer}`;
}

function updateScore() {
    player1AcertosDisplay.textContent = `Jogador 1 - Acertos: ${player1Score.acertos}`;
    player2AcertosDisplay.textContent = `Jogador 2 - Acertos: ${player2Score.acertos}`;

    if (player1Score.acertos === 6 || player2Score.acertos === 6) {
        showWinner();
    }
}

function showWinner() {
    let winner = (player1Score.acertos === 6) ? 'Jogador 1' : 'Jogador 2';
    alert(`Parabéns, ${winner}! Você venceu o jogo!`);
    restartGame();
}


function flipCard() {
    if (lockBoard) return;
    if (this === firstCard) return;

    this.classList.add('flip');

    if (!hasFlippedCard) {
        hasFlippedCard = true;
        firstCard = this;
        return;
    }

    secondCard = this;
    hasFlippedCard = false;
    checkForMatch();
}

function checkForMatch() {
    if (firstCard.dataset.card === secondCard.dataset.card) {
        disableCards();
        updateScore();
    } else {
        unflipCards();
        switchPlayer();
    }
}

function disableCards() {
    if (currentPlayer === 1) {
        player1Score.acertos++;
    } else {
        player2Score.acertos++;
    }

    firstCard.removeEventListener('click', flipCard);
    secondCard.removeEventListener('click', flipCard);

    resetBoard();
}

function unflipCards() {
    lockBoard = true;

    setTimeout(() => {
        firstCard.classList.remove('flip');
        secondCard.classList.remove('flip');

        resetBoard();
        switchPlayer();
        updatePlayerIndicator();
    }, 1500);
}

function resetBoard() {
    [hasFlippedCard, lockBoard] = [false, false];
    [firstCard, secondCard] = [null, null];
}

cards.forEach((card) => {
    card.addEventListener('click', flipCard);
});

restartButton.addEventListener('click', restartGame);

playerIndicator.textContent = `Vez do Jogador ${currentPlayer}`;
updateScore();
shuffleCards();
